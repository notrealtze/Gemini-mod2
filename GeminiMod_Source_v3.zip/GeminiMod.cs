using System;
using System.Reflection;

// Gemini Mod — SC2 API 1.8.2.3
// Uses confirmed hook names from API 1.8 source.

namespace GeminiMod
{
    public class GeminiLoader
    {
        public string Name    => "Gemini";
        public string Author  => "Gemini";
        public string Version => "1.0.0";

        // API 1.8 confirmed hook — fires after all mods loaded
        public void OnLoadingFinished()
        {
            WriteLog("Gemini Mod — OnLoadingFinished fired.");
            ShowDialog(
                "Gemini Mod",
                "Gemini Mod is now active!\n\nVersion 1.0.0\nby Gemini"
            );
        }

        // Backup hook — fires on loading start
        public void OnLoadingStart()
        {
            WriteLog("Gemini Mod — OnLoadingStart fired.");
        }

        // Fires when world is fully loaded
        public void OnWorldLoaded()
        {
            WriteLog("Gemini Mod — OnWorldLoaded fired.");
            ShowDialog(
                "Gemini Mod",
                "Gemini Mod is active in this world!\n\nVersion 1.0.0"
            );
        }

        private static void WriteLog(string message)
        {
            try
            {
                Type? logType = FindType("Engine.Log");
                if (logType != null)
                {
                    MethodInfo? m = logType.GetMethod(
                        "Information",
                        new[] { typeof(string) }
                    );
                    m?.Invoke(null, new object[] { "[Gemini] " + message });
                    return;
                }
            }
            catch { }
            Console.WriteLine("[Gemini] " + message);
        }

        private static void ShowDialog(string title, string body)
        {
            try
            {
                Type? sm = FindType("Game.ScreensManager");
                if (sm == null)
                {
                    WriteLog("ScreensManager not found.");
                    return;
                }

                // Try SwitchScreen with MessageDialog
                MethodInfo? sw = sm.GetMethod(
                    "SwitchScreen",
                    BindingFlags.Public | BindingFlags.Static
                );

                if (sw == null)
                {
                    WriteLog("SwitchScreen not found.");
                    return;
                }

                Action onClose = () =>
                {
                    try
                    {
                        Type? s = FindType("Game.ScreensManager");
                        MethodInfo? m = s?.GetMethod(
                            "SwitchScreen",
                            BindingFlags.Public | BindingFlags.Static
                        );
                        m?.Invoke(null, new object[] {
                            "GameWidget",
                            Array.Empty<object>()
                        });
                    }
                    catch { }
                };

                sw.Invoke(null, new object[] {
                    "MessageDialog",
                    new object[] { title, body, onClose, null }
                });

                WriteLog("Dialog shown.");
            }
            catch (Exception ex)
            {
                WriteLog("ShowDialog error: " + ex.Message);
            }
        }

        private static Type? FindType(string fullName)
        {
            foreach (Assembly asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                try
                {
                    Type? t = asm.GetType(fullName);
                    if (t != null) return t;
                }
                catch { }
            }
            return null;
        }
    }
}
