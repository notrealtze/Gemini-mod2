using System;
using System.Reflection;

// ============================================================
//  Gemini Mod — Survivalcraft 2  |  API 1.8.2.3 / SC 2.4
//
//  This version compiles with NO external references.
//  All SC2 types are accessed via reflection at runtime,
//  so the DLL builds cleanly on any machine without the
//  game's assemblies present.
// ============================================================

namespace GeminiMod
{
    /// <summary>
    /// ModsManager discovers this class by scanning for
    /// public classes whose name ends with "Loader" or
    /// that implement the IModLoader interface by name
    /// (duck-typed via reflection in API 1.8).
    /// </summary>
    public class GeminiLoader
    {
        // ── Mod metadata (read by ModsManager via reflection) ──
        public string Name    => "Gemini";
        public string Author  => "Gemini";
        public string Version => "1.0.0";

        // ── Lifecycle hooks ────────────────────────────────────

        /// <summary>Called once after all mods are loaded.</summary>
        public void OnLoadingStart()
        {
            WriteLog("INFO", "Gemini Mod initialised (OnLoadingStart).");
        }

        /// <summary>
        /// Called every time a world is loaded.
        /// This is where we push the in-game notification.
        /// </summary>
        public void OnWorldLoaded()
        {
            WriteLog("INFO", "Gemini Mod — world loaded, showing dialog.");
            ShowDialog(
                "Gemini Mod",
                "Gemini Mod is now active!\n\nVersion 1.0.0\nby Gemini"
            );
        }

        /// <summary>Called when the player returns to the main menu.</summary>
        public void OnWorldUnloaded()
        {
            WriteLog("INFO", "Gemini Mod — world unloaded.");
        }

        // ── Reflection helpers ─────────────────────────────────

        /// <summary>
        /// Writes to the SC2 log via Log.Information using reflection,
        /// with a plain Console fallback if the type is unavailable.
        /// </summary>
        private static void WriteLog(string level, string message)
        {
            try
            {
                // Locate Engine.Log in the loaded assemblies
                Type? logType = FindType("Engine.Log");
                if (logType != null)
                {
                    MethodInfo? method = logType.GetMethod(
                        level == "INFO" ? "Information" : level == "WARN" ? "Warning" : "Error",
                        new[] { typeof(string) }
                    );
                    method?.Invoke(null, new object[] { "[Gemini] " + message });
                    return;
                }
            }
            catch { /* fall through */ }
            Console.WriteLine($"[Gemini][{level}] {message}");
        }

        /// <summary>
        /// Pushes a MessageDialog onto ScreensManager via reflection.
        /// Falls back to console log if the screen types are unavailable.
        /// </summary>
        private static void ShowDialog(string title, string body)
        {
            try
            {
                Type? screensManager = FindType("Game.ScreensManager");
                if (screensManager == null)
                {
                    WriteLog("WARN", "ScreensManager not found — skipping dialog.");
                    return;
                }

                // ScreensManager.SwitchScreen(string name, params object[] args)
                MethodInfo? switchScreen = screensManager.GetMethod(
                    "SwitchScreen",
                    BindingFlags.Public | BindingFlags.Static
                );

                if (switchScreen == null)
                {
                    WriteLog("WARN", "SwitchScreen method not found.");
                    return;
                }

                // Callback to return to the game after dialog is dismissed
                Action onClose = () =>
                {
                    try
                    {
                        Type? sm = FindType("Game.ScreensManager");
                        MethodInfo? sw = sm?.GetMethod(
                            "SwitchScreen",
                            BindingFlags.Public | BindingFlags.Static
                        );
                        sw?.Invoke(null, new object[] {
                            "GameWidget",
                            Array.Empty<object>()
                        });
                    }
                    catch (Exception ex)
                    {
                        WriteLog("ERROR", "onClose failed: " + ex.Message);
                    }
                };

                switchScreen.Invoke(null, new object[] {
                    "MessageDialog",
                    new object[] { title, body, onClose, null }
                });

                WriteLog("INFO", "Dialog pushed to ScreensManager.");
            }
            catch (Exception ex)
            {
                WriteLog("ERROR", "ShowDialog failed: " + ex.Message);
            }
        }

        /// <summary>
        /// Searches all loaded assemblies for a type by full name.
        /// </summary>
        private static Type? FindType(string fullName)
        {
            foreach (Assembly asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                try
                {
                    Type? t = asm.GetType(fullName);
                    if (t != null) return t;
                }
                catch { /* skip inaccessible assemblies */ }
            }
            return null;
        }
    }
}
